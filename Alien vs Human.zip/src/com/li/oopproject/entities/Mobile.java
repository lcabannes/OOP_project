package com.li.oopproject.entities;

public interface Mobile {
    public void move(); // all classes implementing movable must have a move method
}
