package com.li.oopproject.entities;

public interface Attacks {
    public abstract void reload(int timeElapsed);
}
