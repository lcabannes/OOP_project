# Human Vs Aliens
Created by Cabannes Loic & Zuo Lu


# How To play 
- cd into the directory you saved the file 
- Execute the command line: ```javac src/com/li/oopproject/.java src/com/li/oopproject/entities/.java && java -cp ./src com.li.oopproject.Main```

